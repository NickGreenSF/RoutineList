RoutineList (Chrome Extension)

Keep track of your day-to-day tasks using checkboxes that reset every day at a specific time.

HOW TO RUN THIS EXTENSION FROM THIS REPO:
Download this folder.
Go to Chrome Extensions manager.
Turn on developer mode.
Click "Load unpacked" and load the root of this repository.

DEMO: https://www.youtube.com/watch?v=ZoZizZqtS9M
